// ===============================
// CORE NAVIGATION & PAGE LOADING (SPA)
// ===============================

let currentPage = 'login'; // Start with login after splash

// Page loading functionality for SPA
async function loadPage(page) {
    try {
        currentPage = page;
        
        // Show loading state
        const mainContent = document.getElementById('main-content');
        mainContent.innerHTML = '<div class="loading">Loading...</div>';
        mainContent.classList.remove('hidden');
        
        // Close mobile menu if open
        const mobileMenu = document.querySelector('.mobile-menu');
        if (mobileMenu && mobileMenu.classList.contains('active')) {
            toggleMobileMenu();
        }
        
        let content = '';
        
        if (page === 'login') {
            content = await loadLoginPage();
        } else if (page === 'home') {
            content = await loadHomePage();
        } else if (page === 'register') {
            content = await loadRegisterPage();
        } else {
            showComingSoon(page);
            return;
        }
        
        // Update content
        mainContent.innerHTML = content;
        
        // Re-initialize page-specific functionality
        initializeCurrentPage();
        
        // Scroll to top
        window.scrollTo(0, 0);
        
    } catch (error) {
        console.error('Error loading page:', error);
        document.getElementById('main-content').innerHTML = `
            <div class="error-page">
                <h2>Page Not Found</h2>
                <p>Sorry, the page you're looking for doesn't exist.</p>
                <button onclick="loadPage('login')" class="btn btn-primary">Go to Login</button>
            </div>
        `;
    }
}

// Load login page content
async function loadLoginPage() {
    return `
        <!-- Navigation -->
        <nav class="navbar-container">
            <div class="nav-wrapper">
                <!-- Logo -->
                <div class="nav-logo" onclick="loadPage('home')">
                    <div class="nav-logo-icon">
                        <i class="fas fa-shoe-prints"></i>
                    </div>
                    <span class="nav-logo-text">SNEAK-ER</span>
                </div>

                <!-- Navigation Links -->
                <ul class="nav-links">
                    <li><a href="javascript:void(0)" class="nav-link" onclick="loadPage('home')">Home</a></li>
                    <li><a href="javascript:void(0)" class="nav-link" onclick="showComingSoon('About')">About</a></li>
                    <li><a href="javascript:void(0)" class="nav-link" onclick="showComingSoon('Collections')">Collections</a></li>
                    <li><a href="javascript:void(0)" class="nav-link" onclick="showComingSoon('Contact')">Contact</a></li>
                </ul>

                <!-- Auth Buttons -->
                <div class="nav-auth">
                    <button class="auth-btn login-btn" onclick="loadPage('login')">
                        <i class="fas fa-sign-in-alt"></i>
                        <span>Login</span>
                    </button>
                    <button class="auth-btn register-btn" onclick="loadPage('register')">
                        <i class="fas fa-user-plus"></i>
                        <span>Register</span>
                    </button>
                </div>

                <!-- Mobile Menu Button -->
                <div class="mobile-menu-btn">
                    <div class="menu-bar"></div>
                    <div class="menu-bar"></div>
                    <div class="menu-bar"></div>
                </div>
            </div>

            <!-- Mobile Menu -->
            <div class="mobile-menu">
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="loadPage('home')">Home</a>
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="showComingSoon('About')">About</a>
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="showComingSoon('Collections')">Collections</a>
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="showComingSoon('Contact')">Contact</a>
                <div class="mobile-auth">
                    <button class="auth-btn login-btn" onclick="loadPage('login')">Login</button>
                    <button class="auth-btn register-btn" onclick="loadPage('register')">Register</button>
                </div>
            </div>
        </nav>

        <!-- Login Content -->
        <main class="page-content">
            ${await fetch('login-content.html').then(r => r.text())}
        </main>

        <!-- Footer -->
        ${await fetch('footer-content.html').then(r => r.text())}
    `;
}

// Load home page content
async function loadHomePage() {
    return `
        <!-- Navigation -->
        <nav class="navbar-container">
            <div class="nav-wrapper">
                <!-- Logo -->
                <div class="nav-logo" onclick="loadPage('home')">
                    <div class="nav-logo-icon">
                        <i class="fas fa-shoe-prints"></i>
                    </div>
                    <span class="nav-logo-text">SNEAK-ER</span>
                </div>

                <!-- Navigation Links -->
                <ul class="nav-links">
                    <li><a href="javascript:void(0)" class="nav-link active" onclick="loadPage('home')">Home</a></li>
                    <li><a href="javascript:void(0)" class="nav-link" onclick="showComingSoon('About')">About</a></li>
                    <li><a href="javascript:void(0)" class="nav-link" onclick="showComingSoon('Collections')">Collections</a></li>
                    <li><a href="javascript:void(0)" class="nav-link" onclick="showComingSoon('Contact')">Contact</a></li>
                </ul>

                <!-- Auth Buttons -->
                <div class="nav-auth">
                    <button class="auth-btn login-btn" onclick="loadPage('login')">
                        <i class="fas fa-sign-in-alt"></i>
                        <span>Login</span>
                    </button>
                    <button class="auth-btn register-btn" onclick="loadPage('register')">
                        <i class="fas fa-user-plus"></i>
                        <span>Register</span>
                    </button>
                </div>

                <!-- Mobile Menu Button -->
                <div class="mobile-menu-btn">
                    <div class="menu-bar"></div>
                    <div class="menu-bar"></div>
                    <div class="menu-bar"></div>
                </div>
            </div>

            <!-- Mobile Menu -->
            <div class="mobile-menu">
                <a href="javascript:void(0)" class="mobile-nav-link active" onclick="loadPage('home')">Home</a>
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="showComingSoon('About')">About</a>
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="showComingSoon('Collections')">Collections</a>
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="showComingSoon('Contact')">Contact</a>
                <div class="mobile-auth">
                    <button class="auth-btn login-btn" onclick="loadPage('login')">Login</button>
                    <button class="auth-btn register-btn" onclick="loadPage('register')">Register</button>
                </div>
            </div>
        </nav>

        <!-- Home Content -->
        <main class="page-content">
            ${await fetch('home-content.html').then(r => r.text())}
        </main>

        <!-- Footer -->
        ${await fetch('footer-content.html').then(r => r.text())}
    `;
}

// Load register page content
async function loadRegisterPage() {
    return `
        <!-- Navigation -->
        <nav class="navbar-container">
            <div class="nav-wrapper">
                <!-- Logo -->
                <div class="nav-logo" onclick="loadPage('home')">
                    <div class="nav-logo-icon">
                        <i class="fas fa-shoe-prints"></i>
                    </div>
                    <span class="nav-logo-text">SNEAK-ER</span>
                </div>

                <!-- Navigation Links -->
                <ul class="nav-links">
                    <li><a href="javascript:void(0)" class="nav-link" onclick="loadPage('home')">Home</a></li>
                    <li><a href="javascript:void(0)" class="nav-link" onclick="showComingSoon('About')">About</a></li>
                    <li><a href="javascript:void(0)" class="nav-link" onclick="showComingSoon('Collections')">Collections</a></li>
                    <li><a href="javascript:void(0)" class="nav-link" onclick="showComingSoon('Contact')">Contact</a></li>
                </ul>

                <!-- Auth Buttons -->
                <div class="nav-auth">
                    <button class="auth-btn login-btn" onclick="loadPage('login')">
                        <i class="fas fa-sign-in-alt"></i>
                        <span>Login</span>
                    </button>
                    <button class="auth-btn register-btn" onclick="loadPage('register')">
                        <i class="fas fa-user-plus"></i>
                        <span>Register</span>
                    </button>
                </div>

                <!-- Mobile Menu Button -->
                <div class="mobile-menu-btn">
                    <div class="menu-bar"></div>
                    <div class="menu-bar"></div>
                    <div class="menu-bar"></div>
                </div>
            </div>

            <!-- Mobile Menu -->
            <div class="mobile-menu">
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="loadPage('home')">Home</a>
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="showComingSoon('About')">About</a>
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="showComingSoon('Collections')">Collections</a>
                <a href="javascript:void(0)" class="mobile-nav-link" onclick="showComingSoon('Contact')">Contact</a>
                <div class="mobile-auth">
                    <button class="auth-btn login-btn" onclick="loadPage('login')">Login</button>
                    <button class="auth-btn register-btn" onclick="loadPage('register')">Register</button>
                </div>
            </div>
        </nav>

        <!-- Register Content -->
        <main class="page-content">
            ${await fetch('register-content.html').then(r => r.text())}
        </main>

        <!-- Footer -->
        ${await fetch('footer-content.html').then(r => r.text())}
    `;
}

// Show coming soon message
function showComingSoon(feature) {
    alert(`${feature} feature is coming soon!`);
}

// Smooth scroll to section
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// ===============================
// SPLASH SCREEN FUNCTIONALITY
// ===============================

function initializeSplashScreen() {
    const splashScreen = document.getElementById('splash-screen');
    const mainContent = document.getElementById('main-content');
    
    if (!splashScreen || !mainContent) return;
    
    // Hide splash screen after 3 seconds and go to login
    setTimeout(() => {
        splashScreen.style.opacity = '0';
        splashScreen.style.transition = 'opacity 0.5s ease';
        
        setTimeout(() => {
            splashScreen.style.display = 'none';
            // Load login page after splash screen
            loadPage('login');
        }, 500);
    }, 3000);
}

// ===============================
// FORM HANDLING FUNCTIONS
// ===============================

// Handle login form submission
function handleLoginForm(event) {
    event.preventDefault();
    
    const submitBtn = event.target.querySelector('.submit-btn');
    if (!submitBtn) return;
    
    // Show loading state
    submitBtn.classList.add('loading');
    submitBtn.disabled = true;
    
    // Simulate login process
    setTimeout(() => {
        // For demo - always succeed
        alert('Login successful! Welcome to SNEAK-ER.');
        
        // Reset button state
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;
        
        // Redirect to home page after successful login
        loadPage('home');
    }, 2000);
}

// Handle register form submission
function handleRegisterForm(event) {
    event.preventDefault();
    
    const submitBtn = event.target.querySelector('.submit-btn');
    if (!submitBtn) return;
    
    // Show loading state
    submitBtn.classList.add('loading');
    submitBtn.disabled = true;
    
    // Simulate registration process
    setTimeout(() => {
        alert('Account created successfully! Welcome to SNEAK-ER.');
        
        // Reset button state
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;
        
        // Redirect to home page after registration
        loadPage('home');
    }, 2000);
}

// ===============================
// INITIALIZATION
// ===============================

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Always start with splash screen
    initializeSplashScreen();
    
    // Add dynamic styles
    addDynamicStyles();
});

// Rest of your existing JavaScript functions remain the same...
// (keep all the mobile menu, navbar, particle system, form validation functions from previous version)